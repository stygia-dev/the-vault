player_manager.AddValidModel( "Research Intelligence Sentinel",                     "models/starstep/research_intelligence_sentinel.mdl" )
list.Set( "PlayerOptionsModel",  "Research Intelligence Sentinel",                  "models/starstep/research_intelligence_sentinel.mdl" )
player_manager.AddValidHands( "Research Intelligence Sentinel", 					"models/starstep/ris_hands.mdl", 0, "00000000" );